import CustomerCurd from "./components/CustomerCrud";
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from "jquery";
function App() {
  return (
    <div >
        <CustomerCurd/>
    </div>
  );
}

export default App;
